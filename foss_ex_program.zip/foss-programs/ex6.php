<?php

if(isset($_POST["submit"])){
	foreach ($_POST["sub"] as $select) {
		echo "You Selected :".$select."<br>";
	}
}


  ?>
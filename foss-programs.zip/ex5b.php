<?php  

$a = $_POST['marks'];
if($a>=95){
	echo " Your Grade is A .";
}elseif ($a>=85) {
	echo " Your Grade is B ";
}elseif ($a>=60) {
	echo " Your Grade is C .";
}elseif ($a>=50) {
	echo " Your Grade is D ";
}elseif ($a>=40) {
	echo " Your Grade is E ";
}else{
	echo "Fail";
}

?>
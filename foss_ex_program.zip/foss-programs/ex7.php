<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php

echo "This is an example for redirect the page";

header("Location:http://www.google.com");

?>
</body>
</html>
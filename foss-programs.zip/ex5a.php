<?php
$a=$_POST['numb'];
$fact=1;
for ($i=$a;$i>=1;$i--){
$fact=$fact * $i;}
echo "The  factorial of  ".$a." is : ".$fact;

 ?>

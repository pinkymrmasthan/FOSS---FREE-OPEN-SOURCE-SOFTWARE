<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="padding: 250px 50px;background-color: pink;">
	<center>
<?php 

$a = $_POST["_name"];
echo "HI MR. ".$a;

 ?>

</center>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		.red-message{
    color: red;
    position: absolute;
    text-align: left;
    margin-bottom: 215px;
    margin-top: -50px;
    margin-left: 310px;
		}
		.red-message1{
			color: red;
			position: absolute;
    margin-top: 4px;
    margin-left: 66px; 
		}
	</style>
</head>
<body>
<?php 
$nameErr=$emailErr=$genderErr="";
$name=$email=$gender="";
if($_SERVER['REQUEST_METHOD']=="POST"){
	if(empty($_POST['name'])){
		echo "Please fill name ..";
	}else{
		$pattern="/^[a-zA-z\s]+$/";
		$check=preg_match_all($pattern, $_POST['name']);
		if($check){
			$name=$_POST['name'];
		}else{
			$nameErr="Check the name";
		}
	}
	if(empty($_POST['email'])){
		echo "Please fill email here";
	}else{
		$check=filter_var($_POST['email'],FILTER_VALIDATE_EMAIL);
		if($check){
			$email=$_POST['email'];
		}else{
			$emailErr="Check the email";
		}
	}
	if(empty($_POST['gender'])){
		echo "Select the Gender";
	}else{
		$gender=$_POST['gender'];
	}
}

?>



	<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
		<label>Enter your name :  </label><input type="text" name="name" required="Please fill the Name here.." placeholder="Type name here"><br><br><br><span class="red-message">* <?php echo $nameErr; ?></span></div>
		<div class="form-element">
		<label>Enter your email :  </label><input type="email" name="email" required="Please fill the Email here.." placeholder="Type email here"><br><br><br><span class="red-message">* <?php echo $emailErr; ?></span></div></div>
		<div class="form-element">
		 Gender:
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="female">Female
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="male">Male
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="other") echo "checked";?> value="other">Other  
  <span class="red-message1">* <?php echo $genderErr;?></span>
  <br><br>	
		<input type="submit" name="submit" value="Submit"><br><br></div>
	</form>


<?php
echo "YOUR INPUT DATA<br>";
echo $name."<br>";
echo $email."<br>";
echo $gender."<br>";
?>
</body>
</html>
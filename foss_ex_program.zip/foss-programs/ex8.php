<?php
function sample(){
$a = $_POST['num1'];
$b = $_POST['num2'];
$c = $_POST['choice'];

switch ($c) {
	case 1:
		$d = $a+$b;
		echo "The addition of two numbers : ".$d;
		break;
	case 2:
		$d = $a=$b;
		echo "The subtration of two numbers : ".$d;
		break;
	case 3:
		$d = $a*$b;
		echo "The multiplication of two numbers : ".$d;
		break;
	case 4:
		$d = $a+$b;
		echo "The division of two numbers : ".$d;
		break;
	
	default:
		echo "Please check the input values or the choice value";
		break;
}
}
sample();

?>